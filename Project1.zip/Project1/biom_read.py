from biom import load_table
import matplotlib.pyplot as plt
import matplotlib as mpl
import pandas as pd
import numpy as np
import random
import os

def single_rarefaction(filepath):
    """
    Runs single_rarefaction.py and returns output file location
    Sample size set to 1000
    """
    input = '/study_77_011618-113533/processed_data/219_otu_table.biom'
    output = '/study_77_011618-113533/processed_data/219_otu_table_even1000.biom'
    sample_size = '1000'
    os.system('single_rarefaction.py'+
              ' -i '+filepath+input+
              ' -o '+filepath+output+
              ' -d '+sample_size)
    return output

def parse_table(filepath,rarefaction):
    """
    Passes the rarified table to be parsed
    Returns parsed table
    """
    # Load the table
    biom = load_table(filepath+rarefaction)

    # Define the observations and samples
    otus = biom.ids('observation')
    samples = biom.ids('sample')
    m = biom.matrix_data
    data = [pd.SparseSeries(m[i].toarray().ravel()) for i in np.arange(m.shape[0])]
    table = pd.SparseDataFrame(data, index=otus, columns = samples)
    counts(table)
    return table

def counts(table):
    """
    Counts the sum of the columns to verify that the rarefaction
    had been completed properly.
    """
    for sum in table.sum(axis=0):
        if sum != 1000:
            print("single_rarefaction.py failure.")
    print("Rarefaction check completed.")

def betaDiversity(filepath):
    """
    Runs beta_diversity.py with a bray_curtis_faith metric,
    and returns the beta diversity matrix as a DataFrame
    """
    input = '/study_77_011618-113533/processed_data/219_otu_table_even1000.biom'
    output_dir = '/study_77_011618-113533/processed_data/beta'
    output = '/bray_curtis_faith_219_otu_table_even1000.txt'
    metric = 'bray_curtis_faith'
    os.system('beta_diversity.py'
              +' -i '+filepath+input
              +' -o '+filepath+output_dir
              +' -m '+metric)
    return pd.DataFrame.from_csv(filepath+output_dir+output, sep ='\t')

def label_tables(filepath, betas):
    """
    Returns label lists of sample IDs which 
    correspond to their values in the mapping file
    """
    ez_path = '/study_77_011618-113533/mapping_files/easy_mapping.csv'
    lean=[]
    obese=[]
    lines = []
    with open(filepath+ez_path,'r') as mapping:
        for line in mapping:
            lines.append(line.split(","))
        mapping.close()
    for line in lines:
        if str(line[2]).__contains__("Lean"):
            if line[0] in betas.keys():
                lean.append(line[0])
        elif str(line[2]).__contains__("Obese"):
            if line[0] in betas.keys():
                obese.append(line[0])
    return lean,obese

def break_table(betas, lean, obese):
    """
    Breaks the beta diversity matrix into Lean-vs-Lean, 
    Obese-vs-Obese, and Lean-vs-Obese. The function will
    not allow comparison of self (no distances of zero), 
    and will return lists of distances for each value.
    Each list is saved to its own csv file.
    """
    
    LL_stats = []
    OO_stats = []
    LO_stats = []

    for i in range(len(lean)):
        for j in range(len(betas[lean[i]].keys())):
            if betas[lean[i]].keys()[j] in lean:
                if betas[lean[i]][j] != 0:
                    LL_stats.append(betas[lean[i]][j])
            elif betas[lean[i]].keys()[j] in obese:
                LO_stats.append(betas[lean[i]][j])
    for i in range(len(obese)):
        for j in range(len(betas[obese[i]].keys())):
            if betas[obese[i]].keys()[j] in obese:
                if betas[obese[i]][j]!= 0:
                    OO_stats.append(betas[obese[i]][j])
    print("Lean-vs-Lean:\n "+
          "Low: "+str(min(LL_stats))+
          "\n High: "+str(max(LL_stats))+
          "\n Count: "+str(len(LL_stats)))
    print()
    print("Obese-vs-Obese:\n "+
          "Low: "+str(min(OO_stats))+
          "\n High: "+str(max(OO_stats))+
          "\n Count: "+str(len(OO_stats)))
    print()
    print("Lean-vs-Obese:\n "+
          "Low: "+str(min(LO_stats))+
          "\n high: "+str(max(LO_stats))+
          "\n Count: "+str(len(LO_stats)))
    with open("LL_stats.csv", "wb") as f:
        wr = csv.writer(f,quoting=csv.QUOTE_ALL)
        wr.writerow(LL_stats)
        f.close()
    with open("OO_stats.csv", "wb") as f:
        wr = csv.writer(f,quoting=csv.QUOTE_ALL)
        wr.writerow(OO_stats)
        f.close()
    with open("LO_stats.csv", "wb") as f:
        wr = csv.writer(f,quoting=csv.QUOTE_ALL)
        wr.writerow(LO_stats)
        f.close()
    return LL_stats, OO_stats, LO_stats

def boxplots(LL_stats, OO_stats, LO_stats):
    mpl.use('agg')
    data = sample(LL_stats, OO_stats, LO_stats)
    fig = plt.figure(1, figsize=(9,6))
    ax = fig.add_subplot(111)
    bp = ax.boxplot(data)
    ax.set_title('Comparison of Beta Diversity Dissimilarity\n Sample of 1000')
    ax.set_xticklabels(['Lean vs Lean','Obese vs Obese', 'Lean vs Obese'])
    [flier.set(marker='o',color='#e7298a', alpha=.3) for flier in bp['fliers']]
    fig.savefig("boxplot.png", bbox_inches='tight')

def sample(LL_stats, OO_stats, LO_stats):
    return [random.sample(LL_stats, 1000),
            random.sample(OO_stats, 1000),
            random.sample(LO_stats, 1000)]

def main():
    """
    Define the path to the script, which should be in
    the same directory as study_77_011618-113533
    """
    filepath = '/home/qiime/Desktop/Project1'

    # Rarefaction of biom table, assigns path as variable
    rarefaction = single_rarefaction(filepath)

    # Parses the biom table to be saved as variable
    table = parse_table(filepath,rarefaction)

    # Parses beta diversity matrix
    betas = betaDiversity(filepath)

    # Create Lean and Obese labels
    lean, obese = label_tables(filepath, betas)
    # Lean-vs-Lean, Obese-vs-Obese, and Lean-vs-Obese tables
    LL_stats, OO_stats, LO_stats = break_table(betas, lean, obese)
    # Create the boxplots
    boxplots(LL_stats,OO_stats,LO_stats)




if __name__ == '__main__':
    main()